let workTime = 25 * 60; // 25 minutes in seconds
let breakTime = 5 * 60; // 5 minutes in seconds
let timeLeft = workTime;
let timerInterval = null;
let isRunning = false;
let currentMode = "work";
let volume = 0.5;
let tasks = [];
let completedTasks = 0;
let abandonedTasks = 0;
let currentTask = "";

const timerDisplay = document.getElementById('timer');
const focusButton = document.getElementById('focus');
const breakButton = document.getElementById('break');
const pauseButton = document.getElementById('pause');
const settingsButton = document.getElementById('settings-button');
const settingsDiv = document.getElementById('settings');
const saveSettingsButton = document.getElementById('save-settings');
const closeSettingsButton = document.getElementById('close-settings');
const workTimeInput = document.getElementById('work-time');
const breakTimeInput = document.getElementById('break-time');
const workTimeSound = document.getElementById('work-time-sound');
const breakTimeSound = document.getElementById('break-time-sound');
const taskInput = document.getElementById('task-input');
const taskList = document.getElementById('task-list');
const completedTasksDisplay = document.getElementById('completed-tasks');
const abandonedTasksDisplay = document.getElementById('abandoned-tasks');

function updateDisplay() {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function startTimer(mode) {
  if (!isRunning) {
    isRunning = true;
    currentMode = mode;
    if (mode === "work") {
      timeLeft = workTime;
    } else {
      timeLeft = breakTime;
    }
    timerInterval = setInterval(() => {
      timeLeft--;
      updateDisplay();
      if (timeLeft <= 0) {
        clearInterval(timerInterval);
        isRunning = false;
        if (currentMode === "work") {
          workTimeSound.play();
          alert("Work time is over! Take a break.");
          currentMode = "break";
          timeLeft = breakTime;
          updateDisplay();
        } else {
          breakTimeSound.play();
          alert("Break time is over! Get back to work.");
          currentMode = "work";
          timeLeft = workTime;
          updateDisplay();
        }
      }
    }, 1000);
  }
}

function stopTimer() {
  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;
  }
}

function addTask() {
  const taskText = taskInput.value;
  if (taskText !== "") {
    currentTask = taskText;
    renderTaskList();
    taskInput.value = "";
  }
}

function renderTaskList() {
  taskList.innerHTML = "";
  if (currentTask !== "") {
    const taskItem = document.createElement("li");
    taskItem.classList.add("task-item");
    taskItem.innerHTML = `
      <span>${currentTask}</span>
      <span class="x-icon">&#x2717;</span>
      <span class="check-icon">&#x2713;</span>
    `;
    taskList.appendChild(taskItem);
    const xIcon = taskItem.querySelector(".x-icon");
    const checkIcon = taskItem.querySelector(".check-icon");
    xIcon.addEventListener("click", () => {
      abandonedTasks++;
      abandonedTasksDisplay.textContent = abandonedTasks;
      currentTask = "";
      renderTaskList();
    });
    checkIcon.addEventListener("click", () => {
      completedTasks++;
      completedTasksDisplay.textContent = completedTasks;
      currentTask = "";
      renderTaskList();
    });
  }
}

taskInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    addTask();
  }
});

document.addEventListener("click", (e) => {
  if (e.target !== taskInput && taskInput.value !== "") {
    addTask();
  }
});

settingsButton.addEventListener('click', () => {
  settingsDiv.style.display = (settingsDiv.style.display === 'block') ? 'none' : 'block';
});

closeSettingsButton.addEventListener('click', () => {
  if (confirm("Save changes before closing?")) {
    saveSettingsButton.click();
  }
  settingsDiv.style.display = 'none';
});

saveSettingsButton.addEventListener('click', () => {
  workTime = parseInt(workTimeInput.value) * 60;
  breakTime = parseInt(breakTimeInput.value) * 60;
  settingsDiv.style.display = 'none';
});

focusButton.addEventListener('click', () => {
  startTimer("work");
});

breakButton.addEventListener('click', () => {
  startTimer("break");
});

pauseButton.addEventListener('click', stopTimer);

updateDisplay();
